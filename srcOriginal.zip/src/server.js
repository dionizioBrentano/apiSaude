// src/server.js
const express = require('express');
const cors = require('cors');
const { sequelize } = require('./models'); // Importa a instância do Sequelize
const pessoaRoutes = require('./routes/pessoa.routes');
const authRoutes = require('./routes/authRoutes');
require('dotenv').config(); // Carrega as variáveis de ambiente do .env

const app = express();
const PORT = process.env.PORT || 3333;

// Middlewares
app.use(cors());
app.use(express.json()); // Permite que o Express parseie JSON no corpo das requisições

// Rotas da API
app.use('/api/v1/pessoas', pessoaRoutes);
app.use('/api/v1/auth', authRoutes);

// Sincronizar banco de dados e iniciar servidor
sequelize.authenticate()
    .then(() => {
        console.log('Conexão com o banco de dados estabelecida com sucesso!');
        // Opcional: Para sincronizar os modelos com o banco de dados (cria tabelas se não existirem)
        // CUIDADO: Em produção, você geralmente usa migrações em vez de `sync({ alter: true })` ou `sync({ force: true })`
        // sequelize.sync({ alter: true }) // Isso tenta fazer alterações não destrutivas
        //     .then(() => {
        //         console.log('Modelos sincronizados com o banco de dados.');
        //     })
        //     .catch(syncErr => {
        //         console.error('Erro ao sincronizar modelos:', syncErr);
        //     });

        app.listen(PORT, () => {
            console.log(`Servidor rodando na porta ${PORT}`);
        });
    })
    .catch(err => {
        console.error('Não foi possível conectar ao banco de dados:', err);
    });
    module.exports = app;