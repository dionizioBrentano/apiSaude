const { Pessoa } = require('../models');
const jwt = require('jsonwebtoken');

const authController = {
  /**
   * Autentica um usuário e retorna um token JWT.
   * @param {import('express').Request} req
   * @param {import('express').Response} res
   */
  login: async (req, res) => {
    try {
      const { email, senha } = req.body;

      // 1. Valida se email e senha foram fornecidos
      if (!email || !senha) {
        return res.status(400).json({ message: 'Email e senha são obrigatórios.' });
      }

      // 2. Busca o usuário pelo email
      const pessoa = await Pessoa.findOne({ where: { email } });

      if (!pessoa) {
        // Usamos 401 para não dar dicas a atacantes se o usuário existe ou não
        return res.status(401).json({ message: 'Credenciais inválidas.' });
      }

      // 3. Valida a senha
      // (Esta é a chamada para o método que você definiu no model Pessoa)
      const senhaValida = await pessoa.validarSenha(senha);

      if (!senhaValida) {
        return res.status(401).json({ message: 'Credenciais inválidas.' });
      }

      // 4. Gera o Token JWT
      const payload = {
        id: pessoa.id,
        nome: pessoa.nome_completo,
        email: pessoa.email,
      };

      const token = jwt.sign(
        payload,
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN }
      );

      // 5. Retorna o token para o cliente
      return res.status(200).json({
        message: 'Login bem-sucedido!',
        token,
      });

    } catch (error) {
      console.error('Erro no login:', error);
      return res.status(500).json({ message: 'Ocorreu um erro interno no servidor.' });
    }
  },
};

module.exports = authController;