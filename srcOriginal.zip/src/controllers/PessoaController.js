// src/controllers/PessoaController.js
const { models } = require('../models'); // Acessa o objeto 'models' do index.js
const Pessoa = models.Pessoa;           // Obtém o model Pessoa
const { Op } = require('sequelize');    // Importa Op para operações lógicas no Sequelize
const bcrypt = require('bcryptjs');     // Para o hash da senha

class PessoaController {
    static async cadastrar(req, res) {
        const { nomeCompleto, email, senha, telefoneCelular, dataNascimento } = req.body;

        // Verificação de campos obrigatórios
        if (!nomeCompleto || !email || !senha || !telefoneCelular || !dataNascimento) {
            return res.status(400).json({ message: 'Todos os campos obrigatórios (nomeCompleto, email, senha, telefoneCelular, dataNascimento) devem ser fornecidos.' });
        }

        try {
            // Verificar se o e-mail ou telefone já existem
            const existingPessoa = await Pessoa.findOne({
                where: {
                    [Op.or]: [
                        { email: email },
                        { telefoneCelular: telefoneCelular }
                    ]
                }
            });

            if (existingPessoa) {
                let errorMessage = 'Já existe um cadastro com este ';
                if (existingPessoa.email === email && existingPessoa.telefoneCelular === telefoneCelular) {
                    errorMessage += 'e-mail e telefone celular.';
                } else if (existingPessoa.email === email) {
                    errorMessage += 'e-mail.';
                } else {
                    errorMessage += 'telefone celular.';
                }
                return res.status(409).json({ message: errorMessage });
            }

            // Cria o usuário com status inicial 'PENDENTE_VERIFICACAO'
            const novaPessoa = await Pessoa.create({
                nomeCompleto,
                email,
                senha, // A senha será hashed pelo hook 'beforeCreate' no model Pessoa
                telefoneCelular,
                dataNascimento,
                statusConta: 'PENDENTE_VERIFICACAO' // Define o status inicial
            });

            // Não retorne a senha hashed no JSON de resposta
            const { senha: _, ...pessoaSemSenha } = novaPessoa.toJSON();

            return res.status(201).json({
                message: 'Usuário cadastrado com sucesso! Verificação pendente.',
                user: pessoaSemSenha
            });

        } catch (error) {
            console.error('Erro ao cadastrar pessoa:', error);
            return res.status(500).json({ message: 'Erro interno do servidor ao cadastrar a pessoa.', error: error.message });
        }
    }
}

module.exports = PessoaController;
