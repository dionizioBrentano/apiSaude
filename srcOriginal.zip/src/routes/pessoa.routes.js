// src/routes/pessoa.routes.js
const { Router } = require('express');
const PessoaController = require('../controllers/PessoaController');

const pessoaRouter = Router();

// Rota para cadastro de novas pessoas
pessoaRouter.post('/', PessoaController.cadastrar);

module.exports = pessoaRouter;